/**
 * NeoStripRGBW.h
 *
 * Joseph Spall
 * December 2017
 *
 * Library for the control of Adafruit NeoPixel addressable RGBW LEDs.
 */


#ifndef NEOSTRIPRGBW_H
#define NEOSTRIPRGBW_H

#ifndef TARGET_LPC1768
#error NeoStrip only supports the NXP LPC1768!
#endif

// NeoColorRGBW struct definition to hold 32 bit
// color data for each pixel, in RGBW order
typedef struct _NeoColorRGBW
{
	uint8_t green;
    uint8_t red;
	uint8_t blue;
    uint8_t white;
} NeoColorRGBW;

/**
 * NeoStripRGBW objects manage the buffering and assigning of
 * addressable RGBW NeoPixels
 */
class NeoStripRGBW
{
	public:

		/**
		 * Create a NeoStripRGBW object
		 *
		 * @param pin The mbed data pin name.
		 * @param N The number of pixels in the strip.
		 */
		NeoStripRGBW(PinName pin, int N);

		/**
		 * Set an overall brightness scale for the entire strip.
		 * When colors are set using setPixel(), they are scaled
		 * according to this brightness.
		 *
		 * Because NeoPixels are very bright and draw a lot of current,
		 * the brightness is set to 0.5 by default.
		 *
		 * @param bright The brightness scale between 0 and 1.0.
		 */
		void setBrightness(float bright);

		/**
		 * Set a single pixel to the specified color, with red, green, blue, and white
		 * values in separate arguments.
		 *
		 * @param p The index of the pixel in the strip to set.
		 * @param red The amount of red that should be shown in the pixel
		 * @param blue The amount of blue that should be shown in the pixel
		 * @param green The amount of green that should be shown in the pixel
		 * @param white The amount of white that should be shown in the pixel
		 */
		void setPixel(int p, uint8_t red, uint8_t green, uint8_t blue, uint8_t white);

		/**
		 * Reset all pixels in the strip to be of (0x000000)
		 */
		void clear();

		/**
		 * Write the colors out to the strip; this method must be called
		 * to see any hardware effect.
		 *
		 * This function disables interrupts while the strip data is being sent,
		 * each pixel takes approximately 30us to send, plus a 50us reset pulse
		 * at the end.
		 */
		void write();

	protected:
		NeoColorRGBW *strip;	// pixel data buffer modified by setPixel() and used by neo_out()
		int N;				// the number of pixels in the strip
		int Nbytes;			// the number of bytes of pixel data (always N*4)
		float bright;		// the master strip brightness
		gpio_t gpio;		// gpio struct for initialization and getting register addresses
};

#endif



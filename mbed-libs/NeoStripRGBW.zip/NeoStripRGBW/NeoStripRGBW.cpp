/**********************************************
 * NeoStripRGBW.cpp
 *
 * Joseph Spall IV
 * December 2017
 *
 * Controls a strip of Adafruit NeoPixels, addressable RGBW LEDs
 * Currently, because of the global nature of the IO register and bitmask variables,
 * it is only possible to use one NeoStrip instance at a time.
 *
 * This library supports only the NXP LPC1768!
 */

#include "mbed.h"
#include "NeoStripRGBW.h"

// function to write to the strip, implemented in ARM assembly
extern "C" void neo_out(NeoColorRGBW*, int);

// FastIO register address and bitmask for the GPIO pin
// because these are imported in the assembly
uint32_t neo_fio_reg;
uint32_t neo_bitmask;

NeoStripRGBW::NeoStripRGBW(PinName pin, int N) : N(N)
{
	bright = 0.5;
	Nbytes = N * 4;
	strip = (NeoColorRGBW*)malloc(N * sizeof(NeoColorRGBW));
	if (strip == NULL)
	{
		printf("NeoStripRGBW: ERROR unable to malloc strip data");
		N = 0;
	}
	
	gpio_init_out(&gpio, pin);				// initialize GPIO registers
	neo_fio_reg = (uint32_t)gpio.reg_dir;	// set registers and bitmask for
	neo_bitmask = 1 << ((int)pin & 0x1F);	// the assembly to use
}

void NeoStripRGBW::setBrightness(float bright)
{
	this->bright = bright;
}


void NeoStripRGBW::setPixel(int p, uint8_t red, uint8_t green, uint8_t blue, uint8_t white)
{
	// set the given pixel's RGBW values
	// the array is indexed modulo N to avoid overflow
	strip[p % N].red = (uint8_t)(red * bright);
	strip[p % N].green = (uint8_t)(green * bright);
	strip[p % N].blue = (uint8_t)(blue * bright);
	strip[p % N].white = (uint8_t)(white * bright);
}

void NeoStripRGBW::clear()
{
	for (int i = 0; i < N; i++)
	{
		strip[i].red = 0;
		strip[i].green = 0;
		strip[i].blue = 0;
		strip[i].white = 0;
	}
}

void NeoStripRGBW::write()
{
	__disable_irq();		// disable interrupts
	neo_out(strip, Nbytes);	// output to the strip
	__enable_irq();			// enable interrupts
	wait_us(80);			// wait 80us for the reset pulse
}


